function scrollToForm() {
    document.getElementById("lead-form").scrollIntoView({ behavior: "smooth" });
  }
  
  function startCountdown() {
    const countdownElement = document.getElementById("countdown-timer");
    const targetTime = new Date().getTime() + 48 * 60 * 60 * 1000; // 48 hours from now
  
    function updateCountdown() {
      const currentTime = new Date().getTime();
      const timeLeft = targetTime - currentTime;
  
      if (timeLeft < 0) {
        countdownElement.innerText = "Offer Expired!";
        return;
      }
  
      const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
  
      countdownElement.innerText = `${hours}h ${minutes}m ${seconds}s remaining`;
    }
  
    setInterval(updateCountdown, 1000);
  }
  
  window.onload = startCountdown;
  window.onload = function() {
    const banner = document.getElementById('promo-banner');
    banner.style.display = 'flex'; // Show the banner
  
    // Automatically hide the banner after 10 seconds
    setTimeout(() => {
      banner.style.display = 'none';
    }, 10000);
  };
  
  function closeBanner() {
    document.getElementById('promo-banner').style.display = 'none';
  }
  